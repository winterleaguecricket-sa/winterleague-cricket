import { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import styles from '../../styles/adminProducts.module.css';
import {
  getShirtDesigns,
  addShirtDesign,
  updateShirtDesign,
  deleteShirtDesign,
  toggleShirtDesignStatus
} from '../../data/shirtDesigns';

export default function AdminShirtDesigns() {
  const [designs, setDesigns] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingDesign, setEditingDesign] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    imageUrl: '',
    active: true
  });

  useEffect(() => {
    setDesigns(getShirtDesigns());
  }, []);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file type
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      alert('Please upload a valid image file (JPG, PNG, GIF, or WebP)');
      return;
    }

    // Validate file size (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }

    setUploading(true);
    const formDataUpload = new FormData();
    formDataUpload.append('file', file);

    try {
      const response = await fetch('/api/upload-shirt-design', {
        method: 'POST',
        body: formDataUpload,
      });

      const data = await response.json();
      
      if (data.success) {
        setFormData(prev => ({
          ...prev,
          imageUrl: data.url
        }));
      } else {
        alert('Upload failed: ' + (data.error || 'Unknown error'));
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload image. Please try again.');
    } finally {
      setUploading(false);
    }
  };



  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingDesign) {
      updateShirtDesign(editingDesign.id, formData);
    } else {
      addShirtDesign(formData);
    }
    setDesigns(getShirtDesigns());
    resetForm();
  };

  const handleEdit = (design) => {
    setEditingDesign(design);
    setFormData({
      name: design.name,
      imageUrl: design.imageUrl,
      active: design.active
    });
    setShowAddForm(true);
  };

  const handleDelete = (id) => {
    if (confirm('Are you sure you want to delete this shirt design?')) {
      deleteShirtDesign(id);
      setDesigns(getShirtDesigns());
    }
  };

  const handleToggleStatus = (id) => {
    toggleShirtDesignStatus(id);
    setDesigns(getShirtDesigns());
  };

  const resetForm = () => {
    setFormData({
      name: '',
      imageUrl: '',
      active: true
    });
    setEditingDesign(null);
    setShowAddForm(false);
  };

  return (
    <div className={styles.container}>
      <Head>
        <title>Shirt Design Manager - Admin Panel</title>
      </Head>

      <header className={styles.header}>
        <div className={styles.headerContent}>
          <h1 className={styles.logo}>👕 Shirt Design Manager</h1>
          <nav className={styles.nav}>
            <Link href="/admin" className={styles.navLink}>
              ← Back to Admin
            </Link>
          </nav>
        </div>
      </header>

      <main className={styles.main}>
        <div className={styles.toolbar}>
          <h2>Manage Shirt Designs</h2>
          <button 
            onClick={() => setShowAddForm(!showAddForm)}
            className={styles.addButton}
          >
            {showAddForm ? '✕ Cancel' : '+ Add New Design'}
          </button>
        </div>

        {showAddForm && (
          <div className={styles.formCard}>
            <h3>{editingDesign ? 'Edit Shirt Design' : 'Add New Shirt Design'}</h3>
            <form onSubmit={handleSubmit} className={styles.form}>
              <div className={styles.formGroup}>
                <label>Design Name *</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  placeholder="e.g., Classic Red Stripe"
                  className={styles.input}
                />
              </div>

              <div className={styles.formGroup}>
                <label>Image URL or Upload from PC *</label>
                <input
                  type="text"
                  name="imageUrl"
                  value={formData.imageUrl}
                  onChange={handleInputChange}
                  required
                  placeholder="https://example.com/shirt-image.jpg or upload below"
                  className={styles.input}
                />
                
                <div style={{ margin: '1rem 0', textAlign: 'center', color: '#6b7280', fontSize: '0.9rem' }}>
                  <span>— OR —</span>
                </div>

                <label 
                  htmlFor="fileUpload" 
                  style={{
                    display: 'block',
                    padding: '1rem',
                    background: uploading ? '#f3f4f6' : '#fef2f2',
                    border: '2px dashed #dc0000',
                    borderRadius: '8px',
                    textAlign: 'center',
                    cursor: uploading ? 'not-allowed' : 'pointer',
                    transition: 'all 0.3s ease'
                  }}
                >
                  <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>
                    {uploading ? '⏳' : '📁'}
                  </div>
                  <div style={{ color: '#dc0000', fontWeight: '500' }}>
                    {uploading ? 'Uploading...' : 'Upload from PC'}
                  </div>
                  <div style={{ fontSize: '0.8rem', color: '#6b7280', marginTop: '0.25rem' }}>
                    JPG, PNG, GIF, WebP (Max 5MB)
                  </div>
                </label>
                <input
                  id="fileUpload"
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  disabled={uploading}
                  style={{ display: 'none' }}
                />

                {formData.imageUrl && (
                  <div style={{ marginTop: '1rem' }}>
                    <p style={{ fontSize: '0.9rem', color: '#6b7280', marginBottom: '0.5rem' }}>
                      Preview:
                    </p>
                    <img 
                      src={formData.imageUrl} 
                      alt="Preview"
                      style={{ 
                        width: '200px', 
                        height: '200px', 
                        objectFit: 'cover', 
                        borderRadius: '8px',
                        border: '2px solid #e5e7eb'
                      }}
                      onError={(e) => {
                        e.target.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="200" height="200"%3E%3Crect fill="%23ddd" width="200" height="200"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" fill="%23999"%3EInvalid URL%3C/text%3E%3C/svg%3E';
                      }}
                    />
                  </div>
                )}
              </div>

              <div style={{ padding: '1rem', background: '#f0f9ff', border: '2px solid #0ea5e9', borderRadius: '8px', marginBottom: '1.5rem' }}>
                <p style={{ margin: 0, fontSize: '0.9rem', color: '#0c4a6e' }}>
                  💡 <strong>Note:</strong> Coaches will choose their own color combinations (primary & secondary) when selecting this design in forms.
                </p>
              </div>

              <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  name="active"
                  checked={formData.active}
                  onChange={handleInputChange}
                  style={{ width: '20px', height: '20px', accentColor: '#dc0000' }}
                />
                <span style={{ fontSize: '0.95rem' }}>Active (visible in forms)</span>
              </label>

              <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1.5rem' }}>
                <button type="submit" className={styles.submitBtn}>
                  {editingDesign ? 'Update Design' : 'Add Design'}
                </button>
                <button 
                  type="button" 
                  onClick={resetForm}
                  className={styles.cancelBtn}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        <div className={styles.grid}>
          {designs.length === 0 ? (
            <p style={{ gridColumn: '1 / -1', textAlign: 'center', color: '#6b7280', padding: '3rem' }}>
              No shirt designs yet. Click "Add New Design" to create one.
            </p>
          ) : (
            designs.map(design => (
              <div key={design.id} className={styles.card} style={{ opacity: design.active ? 1 : 0.6 }}>
                <div style={{ position: 'relative' }}>
                  <img 
                    src={design.imageUrl} 
                    alt={design.name}
                    className={styles.productImage}
                    style={{ width: '100%', height: '250px', objectFit: 'cover', borderRadius: '8px' }}
                    onError={(e) => {
                      e.target.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="200" height="200"%3E%3Crect fill="%23ddd" width="200" height="200"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" fill="%23999"%3ENo Image%3C/text%3E%3C/svg%3E';
                    }}
                  />
                  {!design.active && (
                    <div style={{
                      position: 'absolute',
                      top: '0.5rem',
                      right: '0.5rem',
                      background: '#dc0000',
                      color: 'white',
                      padding: '0.25rem 0.75rem',
                      borderRadius: '4px',
                      fontSize: '0.85rem',
                      fontWeight: 'bold'
                    }}>
                      INACTIVE
                    </div>
                  )}
                </div>
                
                <div className={styles.cardContent}>
                  <h3 style={{ margin: '0 0 1rem 0', fontSize: '1.1rem' }}>{design.name}</h3>

                  <div className={styles.cardActions}>
                    <button 
                      onClick={() => handleToggleStatus(design.id)}
                      style={{
                        padding: '0.5rem 1rem',
                        background: design.active ? '#fef3c7' : '#dcfce7',
                        color: design.active ? '#92400e' : '#166534',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '0.85rem',
                        fontWeight: '500'
                      }}
                    >
                      {design.active ? 'Deactivate' : 'Activate'}
                    </button>
                    <button 
                      onClick={() => handleEdit(design)}
                      className={styles.editButton}
                    >
                      Edit
                    </button>
                    <button 
                      onClick={() => handleDelete(design.id)}
                      className={styles.deleteButton}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </main>
    </div>
  );
}
