// Shirt designs library
let shirtDesigns = [
  {
    id: 1,
    name: 'Classic Red Stripe',
    imageUrl: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=300&fit=crop',
    active: true,
    createdAt: new Date('2025-11-01T10:00:00').toISOString()
  },
  {
    id: 2,
    name: 'Blue Lightning',
    imageUrl: 'https://images.unsplash.com/photo-1622279457486-62dcc4a431d6?w=300&h=300&fit=crop',
    active: true,
    createdAt: new Date('2025-11-01T10:05:00').toISOString()
  },
  {
    id: 3,
    name: 'Green Thunder',
    imageUrl: 'https://images.unsplash.com/photo-1598032895397-d4e733ad8b33?w=300&h=300&fit=crop',
    active: true,
    createdAt: new Date('2025-11-01T10:10:00').toISOString()
  },
  {
    id: 4,
    name: 'Yellow Storm',
    imageUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=300&h=300&fit=crop',
    active: true,
    createdAt: new Date('2025-11-01T10:15:00').toISOString()
  }
];

let shirtDesignIdCounter = 5;

// Available colors for team selection (Primary colors only)
export const availableColors = [
  { name: 'Red', hex: '#DC2626' },
  { name: 'Blue', hex: '#2563EB' },
  { name: 'Green', hex: '#16A34A' },
  { name: 'Yellow', hex: '#EAB308' },
  { name: 'Orange', hex: '#EA580C' },
  { name: 'Purple', hex: '#9333EA' },
  { name: 'Black', hex: '#000000' }
];

// Get all shirt designs
export function getShirtDesigns(activeOnly = false) {
  if (activeOnly) {
    return shirtDesigns.filter(design => design.active);
  }
  return [...shirtDesigns];
}

// Get single shirt design by ID
export function getShirtDesignById(id) {
  return shirtDesigns.find(design => design.id === id);
}

// Add new shirt design
export function addShirtDesign(design) {
  const newDesign = {
    ...design,
    id: shirtDesignIdCounter++,
    active: design.active !== undefined ? design.active : true,
    createdAt: new Date().toISOString()
  };
  shirtDesigns.push(newDesign);
  return newDesign;
}

// Update shirt design
export function updateShirtDesign(id, updates) {
  const index = shirtDesigns.findIndex(design => design.id === id);
  if (index !== -1) {
    shirtDesigns[index] = { ...shirtDesigns[index], ...updates };
    return shirtDesigns[index];
  }
  return null;
}

// Delete shirt design
export function deleteShirtDesign(id) {
  const index = shirtDesigns.findIndex(design => design.id === id);
  if (index !== -1) {
    shirtDesigns.splice(index, 1);
    return true;
  }
  return false;
}

// Toggle active status
export function toggleShirtDesignStatus(id) {
  const design = shirtDesigns.find(d => d.id === id);
  if (design) {
    design.active = !design.active;
    return design;
  }
  return null;
}
