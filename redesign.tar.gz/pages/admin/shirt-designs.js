import { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import styles from '../../styles/adminProducts.module.css';
import {
  getShirtDesigns,
  addShirtDesign,
  updateShirtDesign,
  deleteShirtDesign,
  toggleShirtDesignStatus
} from '../../data/shirtDesigns';

export default function AdminShirtDesigns() {
  const [designs, setDesigns] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingDesign, setEditingDesign] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    imageUrl: '',
    active: true
  });

  useEffect(() => {
    setDesigns(getShirtDesigns());
  }, []);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file type
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      alert('Please upload a valid image file (JPG, PNG, GIF, or WebP)');
      return;
    }

    // Validate file size (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }

    setUploading(true);
    const formDataUpload = new FormData();
    formDataUpload.append('file', file);

    try {
      const response = await fetch('/api/upload-shirt-design', {
        method: 'POST',
        body: formDataUpload,
      });

      const data = await response.json();
      
      if (data.success) {
        setFormData(prev => ({
          ...prev,
          imageUrl: data.url
        }));
      } else {
        alert('Upload failed: ' + (data.error || 'Unknown error'));
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload image. Please try again.');
    } finally {
      setUploading(false);
    }
  };



  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingDesign) {
      updateShirtDesign(editingDesign.id, formData);
    } else {
      addShirtDesign(formData);
    }
    setDesigns(getShirtDesigns());
    resetForm();
  };

  const handleEdit = (design) => {
    setEditingDesign(design);
    setFormData({
      name: design.name,
      imageUrl: design.imageUrl,
      active: design.active
    });
    setShowAddForm(true);
  };

  const handleDelete = (id) => {
    if (confirm('Are you sure you want to delete this shirt design?')) {
      deleteShirtDesign(id);
      setDesigns(getShirtDesigns());
    }
  };

  const handleToggleStatus = (id) => {
    toggleShirtDesignStatus(id);
    setDesigns(getShirtDesigns());
  };

  const resetForm = () => {
    setFormData({
      name: '',
      imageUrl: '',
      active: true
    });
    setEditingDesign(null);
    setShowAddForm(false);
  };

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #000000 0%, #1a1a1a 100%)' }}>
      <Head>
        <title>Shirt Design Manager - Admin Panel</title>
      </Head>

      <header style={{ background: 'rgba(0,0,0,0.8)', borderBottom: '2px solid #dc0000', padding: '1rem 2rem' }}>
        <div style={{ maxWidth: '1400px', margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h1 style={{ color: 'white', fontSize: '1.5rem', margin: 0 }}>👕 Shirt Designs</h1>
          <Link href="/admin" style={{ color: '#dc0000', textDecoration: 'none', fontWeight: '600', fontSize: '0.95rem' }}>
            ← Back to Admin
          </Link>
        </div>
      </header>

      <main style={{ maxWidth: '1400px', margin: '0 auto', padding: '2rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
          <h2 style={{ color: 'white', fontSize: '1.3rem', margin: 0 }}>Manage Designs</h2>
          <button 
            onClick={() => setShowAddForm(!showAddForm)}
            style={{
              background: showAddForm ? '#6b7280' : 'linear-gradient(135deg, #dc0000 0%, #ff0000 100%)',
              color: 'white',
              border: 'none',
              padding: '0.75rem 1.5rem',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: '600',
              fontSize: '0.95rem',
              boxShadow: '0 4px 12px rgba(220, 0, 0, 0.3)',
              transition: 'all 0.3s'
            }}
          >
            {showAddForm ? '✕ Cancel' : '+ Add New Design'}
          </button>
        </div>

        {showAddForm && (
          <div style={{ 
            background: 'linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 100%)', 
            border: '2px solid #dc0000', 
            borderRadius: '12px', 
            padding: '1.5rem',
            marginBottom: '2rem',
            boxShadow: '0 8px 24px rgba(0,0,0,0.4)'
          }}>
            <h3 style={{ color: 'white', margin: '0 0 1rem 0', fontSize: '1.1rem' }}>
              {editingDesign ? '✏️ Edit Design' : '➕ Add New Design'}
            </h3>
            <form onSubmit={handleSubmit} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
              <div>
                <label style={{ color: '#dc0000', fontWeight: '600', fontSize: '0.9rem', display: 'block', marginBottom: '0.5rem' }}>
                  Design Name *
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  placeholder="e.g., Classic Red Stripe"
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    background: '#000',
                    border: '2px solid #333',
                    borderRadius: '8px',
                    color: 'white',
                    fontSize: '0.95rem',
                    boxSizing: 'border-box'
                  }}
                />
                
                <label style={{ color: '#dc0000', fontWeight: '600', fontSize: '0.9rem', display: 'block', marginTop: '1rem', marginBottom: '0.5rem' }}>
                  Upload Image *
                </label>
                
                <label 
                  htmlFor="fileUpload" 
                  style={{
                    display: 'block',
                    padding: '1.5rem 1rem',
                    background: uploading ? '#1a1a1a' : 'rgba(220, 0, 0, 0.1)',
                    border: '2px dashed #dc0000',
                    borderRadius: '8px',
                    textAlign: 'center',
                    cursor: uploading ? 'not-allowed' : 'pointer',
                    transition: 'all 0.3s'
                  }}
                >
                  <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>
                    {uploading ? '⏳' : '📁'}
                  </div>
                  <div style={{ color: '#dc0000', fontWeight: '600', fontSize: '0.95rem' }}>
                    {uploading ? 'Uploading...' : 'Click to Upload'}
                  </div>
                  <div style={{ fontSize: '0.8rem', color: '#999', marginTop: '0.25rem' }}>
                    JPG, PNG, GIF, WebP (Max 5MB)
                  </div>
                </label>
                <input
                  id="fileUpload"
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  disabled={uploading}
                  required={!formData.imageUrl && !editingDesign}
                  style={{ display: 'none' }}
                />

                <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', marginTop: '1rem' }}>
                  <input
                    type="checkbox"
                    name="active"
                    checked={formData.active}
                    onChange={handleInputChange}
                    style={{ width: '18px', height: '18px', accentColor: '#dc0000' }}
                  />
                  <span style={{ fontSize: '0.9rem', color: 'white' }}>Active (visible in forms)</span>
                </label>

                <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1rem' }}>
                  <button 
                    type="submit" 
                    style={{
                      flex: 1,
                      background: 'linear-gradient(135deg, #dc0000 0%, #ff0000 100%)',
                      color: 'white',
                      border: 'none',
                      padding: '0.75rem',
                      borderRadius: '8px',
                      fontWeight: '600',
                      cursor: 'pointer',
                      fontSize: '0.95rem'
                    }}
                  >
                    {editingDesign ? 'Update' : 'Add Design'}
                  </button>
                  <button 
                    type="button" 
                    onClick={resetForm}
                    style={{
                      flex: 1,
                      background: '#333',
                      color: 'white',
                      border: 'none',
                      padding: '0.75rem',
                      borderRadius: '8px',
                      fontWeight: '600',
                      cursor: 'pointer',
                      fontSize: '0.95rem'
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </div>

              <div>
                {formData.imageUrl ? (
                  <div>
                    <label style={{ color: '#10b981', fontWeight: '600', fontSize: '0.9rem', display: 'block', marginBottom: '0.5rem' }}>
                      ✓ Preview
                    </label>
                    <div style={{ 
                      background: '#000', 
                      borderRadius: '8px', 
                      padding: '1rem',
                      border: '2px solid #dc0000',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      minHeight: '300px'
                    }}>
                      <img 
                        src={formData.imageUrl} 
                        alt="Preview"
                        style={{ 
                          maxWidth: '100%', 
                          maxHeight: '350px',
                          width: 'auto',
                          height: 'auto', 
                          objectFit: 'contain', 
                          borderRadius: '8px'
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  <div style={{
                    background: '#1a1a1a',
                    border: '2px dashed #333',
                    borderRadius: '8px',
                    padding: '2rem',
                    textAlign: 'center',
                    color: '#666',
                    minHeight: '300px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexDirection: 'column'
                  }}>
                    <div style={{ fontSize: '3rem', marginBottom: '0.5rem' }}>📷</div>
                    <div>Upload an image to preview</div>
                  </div>
                )}
              </div>
            </form>
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1.5rem' }}>
          {designs.length === 0 ? (
            <div style={{ gridColumn: '1 / -1', textAlign: 'center', padding: '3rem', color: '#666' }}>
              No shirt designs yet. Click "Add New Design" to create one.
            </div>
          ) : (
            designs.map(design => (
              <div 
                key={design.id} 
                style={{ 
                  background: 'linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 100%)',
                  border: `2px solid ${design.active ? '#dc0000' : '#333'}`,
                  borderRadius: '12px',
                  overflow: 'hidden',
                  opacity: design.active ? 1 : 0.6,
                  transition: 'all 0.3s',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.4)'
                }}
              >
                <div style={{ position: 'relative', width: '100%', height: '200px', overflow: 'hidden', background: '#000' }}>
                  <img 
                    src={design.imageUrl} 
                    alt={design.name}
                    style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                    onError={(e) => {
                      e.target.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="200" height="200"%3E%3Crect fill="%23333" width="200" height="200"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" fill="%23666"%3ENo Image%3C/text%3E%3C/svg%3E';
                    }}
                  />
                  {!design.active && (
                    <div style={{
                      position: 'absolute',
                      top: '0.5rem',
                      right: '0.5rem',
                      background: '#666',
                      color: 'white',
                      padding: '0.25rem 0.75rem',
                      borderRadius: '6px',
                      fontSize: '0.75rem',
                      fontWeight: 'bold'
                    }}>
                      INACTIVE
                    </div>
                  )}
                </div>
                
                <div style={{ padding: '1rem' }}>
                  <h3 style={{ margin: '0 0 1rem 0', fontSize: '1rem', color: 'white', fontWeight: '600' }}>
                    {design.name}
                  </h3>

                  <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <button 
                      onClick={() => handleToggleStatus(design.id)}
                      style={{
                        flex: '1',
                        minWidth: '80px',
                        padding: '0.5rem 0.75rem',
                        background: design.active ? 'rgba(251, 191, 36, 0.2)' : 'rgba(16, 185, 129, 0.2)',
                        color: design.active ? '#fbbf24' : '#10b981',
                        border: `1px solid ${design.active ? '#fbbf24' : '#10b981'}`,
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '0.8rem',
                        fontWeight: '600',
                        transition: 'all 0.3s'
                      }}
                    >
                      {design.active ? 'Hide' : 'Show'}
                    </button>
                    <button 
                      onClick={() => handleEdit(design)}
                      style={{
                        flex: '1',
                        minWidth: '60px',
                        padding: '0.5rem 0.75rem',
                        background: 'rgba(220, 0, 0, 0.2)',
                        color: '#dc0000',
                        border: '1px solid #dc0000',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '0.8rem',
                        fontWeight: '600',
                        transition: 'all 0.3s'
                      }}
                    >
                      Edit
                    </button>
                    <button 
                      onClick={() => handleDelete(design.id)}
                      style={{
                        padding: '0.5rem 0.75rem',
                        background: 'rgba(239, 68, 68, 0.2)',
                        color: '#ef4444',
                        border: '1px solid #ef4444',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '0.8rem',
                        fontWeight: '600',
                        transition: 'all 0.3s'
                      }}
                    >
                      🗑
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </main>
    </div>
  );
}
